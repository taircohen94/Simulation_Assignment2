import simpy
import pygame
import random

height = 600
width = 600
# 1 meter = 40 pixels

colors = {'BLUE': (0, 0, 255), 'WHITE': (255, 255, 255), 'GREEN': (0, 255, 0)}
door = (width, height/2)
interval = 10

class Person():
    def __init__(self, pos_x, pos_y, speed=15):
        self.x = pos_x
        self.y = pos_y
        self.locations = []
        self.speed = speed
        self.total_time_to_exit = 0
        self.exit = False

    def getLocation(self):
        return (self.x, self.y)

def getRandomPosition():
    return random.randint(0,height), random.randint(0,width)

def movePerson(env, person):
    while True:

        if person.y < door[1]:
            person.y += person.speed
        elif person.y > door[1]:
            person.y -= person.speed

        if person.y > door[1]-person.speed and person.y < door[1]+person.speed:
            person.y = door[1]

        if person.x < door[0]:
            person.x += person.speed

        if person.x >= door[0] and person.y == door[1]:
            person.total_time_to_exit = env.now/100
            person.x = door[0]
            break

        person.locations.append(person.getLocation())
        yield env.timeout(interval)

def movePersons(env, persons):
    while True:

        for person in persons:
            if person.y < door[1]:
                person.y += person.speed
            elif person.y > door[1]:
                person.y -= person.speed

            if person.y > door[1]-person.speed and person.y < door[1]+person.speed:
                person.y = door[1]

            if person.x < door[0]:
                person.x += person.speed

            if person.x >= door[0] and person.y == door[1]:
                person.total_time_to_exit = env.now/100
                person.x = door[0]
                person.exit = True

            person.locations.append(person.getLocation())
            yield env.timeout(interval)

        if all([per.exit for per in persons]):
            break


def simulatePerson(person):

    i = 0
    move = True

    while move:
        display.fill(colors['WHITE'])
        location = person.locations[i]

        i += 1

        if i == len(person.locations):
            move = False

        pygame.draw.circle(display, colors['GREEN'], door, 10)
        pygame.draw.circle(display, colors['BLUE'], location, 10)

        for event in pygame.event.get():
            if event.type == pygame.QUIT or location[0] > height or location[1] > width:
                pygame.quit()
                quit()

        # Draws to the screen
        pygame.display.update()
        clock.tick(interval)


def simulatePersons(persons):

    i = 0
    move = True
    # infinite loop
    while move:
        display.fill(colors['WHITE'])
        pygame.draw.circle(display, colors['GREEN'], door, 10)

        for person in persons:
            if i < len(person.locations):
                location = person.locations[i]
                pygame.draw.circle(display, colors['BLUE'], location, 10)


        i += 1

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                # quit the program.
                quit()
            # Draws the surface object to the screen.
        pygame.display.update()
        clock.tick(interval)


#1 random person simulation
"""
x,y = getRandomPosition()
person = Person(x,y)

env = simpy.Environment()
env.process(movePerson(env, person))
env.run()

pygame.init()  
display = pygame.display.set_mode((height, width))  
clock = pygame.time.Clock()  
pygame.display.set_caption('Panic Room Simulation')  
simulatePerson(person)
"""

#multiple random person simulation
num = 10 # num of persons
persons = []

for i in range(num):
    x,y = getRandomPosition()
    person = Person(x,y)
    persons.append(person)

env = simpy.Environment()
env.process(movePersons(env, persons))
env.run()

pygame.init()
display = pygame.display.set_mode((height, width))
clock = pygame.time.Clock()
pygame.display.set_caption('Panic Room Simulation')
simulatePersons(persons)