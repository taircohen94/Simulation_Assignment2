from Entity import Entity
import random
import matplotlib.pyplot as plt

# arrayOfTimes = [0]*20
# for i in range(0, 20):
#     x = random.randint(1, 15)
#     y = random.randint(1, 15)
#     e = Entity([x, y])
#     door_location = [15, 7.5]
#     arrayOfTimes[i] = e.simulation1a(door_location)
#     print(i)
# print(arrayOfTimes)

# C:
def isCollapse(x1,x2,y1,y2):
    if pow(pow(abs(x1-x2),2)+pow(abs(y1-y2),2),0.5)<0.5:
        return True
    return False
def question_c():
    locations = [0] * 200
    for i in range(0, 200):
        x = random.randint(1, 15)
        y = random.randint(1, 15)
        e = Entity([x, y])
        door_location = [15, 7.5]
        locations[i] = e.simulation1a(door_location)
    collaps=0
    for j in range(0,199):
        for k in range(j+1,200):
            min_length= min(len(locations[j]),len(locations[k]))
            for index in range(0,min_length):
                if isCollapse(locations[j][index][0],locations[k][index][0],locations[j][index][1],locations[k][index][1]):
                    collaps=collaps+1

    print(collaps)
question_c()

#A :
def question_a():
    e = Entity([7.5, 7.5])
    door_location = [15, 7.5]
    locations_x,locations_y,vel_x,vel_y ,time = e.simulation1a(door_location)
    # x axis values
    x = [0]*len(vel_x)
    for i in range(0, len(vel_y)):
        x[i]=i


# corresponding y axis values

# plotting the points
# plt.plot(x, locations_y)
#
# # naming the x axis
# plt.xlabel('Time')
# # naming the y axis
# plt.ylabel('Location')
#
# # giving a title to my graph
# plt.title('Location As Time - Y ')
#
# # function to show the plot
# plt.show()

# plotting the points
    plt.plot(x, vel_x)

    # naming the x axis
    plt.xlabel('Time')
    # naming the y axis
    plt.ylabel('Velocity')

    # giving a title to my graph
    plt.title('Velocity As Time ')

    # function to show the plot
    plt.show()

