import pprint

from Entity2 import Entity2
import random
import math
import copy

door_location = [15, 7.5]


def create_entities(num_of_entities):
    entities = list()

    for i in range(0, num_of_entities):
        x = random.randint(1, 15)
        y = random.randint(1, 15)
        e = Entity2([x, y])
        entities.append(e)
    return entities


def calculate_distance_from_door(e):
    ei0 = [0] * 2
    ei0[0] = door_location[0] - e.curr_r_position[0]
    ei0[1] = door_location[1] - e.curr_r_position[1]
    return math.pow(ei0[0] ** 2 + ei0[1] ** 2, 0.5)


def calculate_distance_from_other_entity(other, e, temp_r):
    ei0 = [0] * 2
    ei0[0] = other.curr_r_position[0] - temp_r[0]
    ei0[1] = other.curr_r_position[1] - temp_r[1]
    return math.pow(ei0[0] ** 2 + ei0[1] ** 2, 0.5)


def check_who_is_in_front_of_entity(other_entities, e):
    closest_entities = list()
    e_distance_from_door = calculate_distance_from_door(e)
    for other in other_entities:
        other_distance = calculate_distance_from_door(other)
        if other_distance < e_distance_from_door:
            closest_entities.append(other)
    return closest_entities


def check_if_legal_move(closest_entities, e, temp_r):
    for other in closest_entities:
        distance = calculate_distance_from_other_entity(other, e, temp_r)
        if distance < 0.5:
        # if abs(temp_r[0]-other.curr_r_position[0]) < 0.5 or abs(temp_r[1]-other.curr_r_position[1]) < 0.5:
            return False
    return True


def simulation2(num_of_entities):
    entities = create_entities(num_of_entities)
    sorted_entities = sorted(entities, key=calculate_distance_from_door)
    k = 0
    while not len(sorted_entities) == 0:
        for e in sorted_entities:
            # find all the entities that are in front of me (closer to the door than me)
            closest_entities = check_who_is_in_front_of_entity(sorted_entities, e)

            # calculate ei0
            ei0 = e.calculate_direction(door_location)

            # calculate dvi_dt, vi=prev_v_velocity
            change_of_velocity = e.dvi_dt(ei0)

            # calculate vi
            e.prev_v_velocity[0] = change_of_velocity[0] + e.prev_v_velocity[0]
            e.prev_v_velocity[1] = change_of_velocity[1] + e.prev_v_velocity[1]

            # calculate ri
            temp_r = [0]*2
            temp_r[0] = e.curr_r_position[0] + e.prev_v_velocity[0] * 0.01
            temp_r[1] = e.curr_r_position[1] + e.prev_v_velocity[1] * 0.01



            # check if anyone is less than 0.5 meters away from me, if so, the move is not legal
            if check_if_legal_move(closest_entities, e, temp_r):
                # e.prev_r_position = copy.deepcopy(e.curr_r_position)
                e.curr_r_position = copy.deepcopy(temp_r)
                if e.check_if_reached_door(door_location):
                    sorted_entities.remove(e)
            #else:
                # print(e.curr_r_position)
                # print(temp_r)
                # print(k)
                # print("*****")
        k = k + 1
    return k


#2A
print("20:")
print(simulation2(20))
print()
print("50:")
print(simulation2(50))
print()
print("100:")
print(simulation2(100))
print()
print("200:")
print(simulation2(200))
print()
