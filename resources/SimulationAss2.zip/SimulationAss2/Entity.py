import math

class Entity:
    def __init__(self, r, v0=1.5):
        self.prev_v_velocity = [0, 0]
        self.prev_r_position = r
        self.acceleration_time = 0.5
        self.v0 = v0

    def simulation1a(self, door_location):
        k = 0
        locations_x=list()
        locations_y=list()
        locations = list()
        vel_x = list()
        vel_y = list()
        vel_x.append(0)
        vel_y.append(0)

        # while position not at door

        while not self.check_if_reached_door(door_location):
            # calculate ei0
            ei0 = self.calculate_direction(door_location)

            # call dvi_dt, vi=prev_v_velocity
            change_of_velocity = self.dvi_dt(ei0)

            # calculate vi
            self.prev_v_velocity[0] = change_of_velocity[0] + self.prev_v_velocity[0]
            self.prev_v_velocity[1] = change_of_velocity[1] + self.prev_v_velocity[1]

            # calculate ri
            self.prev_r_position[0] = self.prev_r_position[0] + self.prev_v_velocity[0]*0.01
            self.prev_r_position[1] = self.prev_r_position[1] + self.prev_v_velocity[1]*0.01
            locations_x.append(self.prev_r_position[0])
            locations_y.append(self.prev_r_position[1])
            array=[0]*2
            array[0]=self.prev_r_position[0]
            array[1]=self.prev_r_position[1]
            locations.append(array)
            vel_x.append(self.prev_v_velocity[0])
            vel_y.append(self.prev_v_velocity[1])
            k = k + 1
            # print(k)
        return locations


    def check_if_reached_door(self, door_location):
        if door_location[0] == 15:
            if self.prev_r_position[0] >= door_location[0] and abs(self.prev_r_position[1]-door_location[1]) <= 0.5:
                return True
        return False

    def calculate_direction(self, door_location):
        ei0 = [0]*2
        ei0[0] = door_location[0] - self.prev_r_position[0]
        ei0[1] = door_location[1] - self.prev_r_position[1]

        distance = math.pow(ei0[0]**2 + ei0[1]**2, 0.5)
        ei0[0] = ei0[0]/distance
        ei0[1] = ei0[1]/distance

        return ei0


    # the change of velocity in time t
    def dvi_dt(self, ei0):
        ans = [0]*2
        ans[0] = self.v0 * ei0[0]
        ans[1] = self.v0 * ei0[1]
        ans[0] = ans[0] - self.prev_v_velocity[0]
        ans[1] = ans[1] - self.prev_v_velocity[1]
        ans[0] = ans[0]*0.01/self.acceleration_time
        ans[1] = ans[1]*0.01/self.acceleration_time
        return ans
        # return [self.prev_v_velocity[0]+(self.v0*ei0[0]-self.prev_v_velocity[0])*0.01/self.acceleration_time,self.prev_v_velocity[1]+(self.v0*ei0[1]-self.prev_v_velocity[1])*0.01/self.acceleration_time]



